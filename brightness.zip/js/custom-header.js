//============================================================================== */
//* CoundDown Initial Script
//============================================================================== */
jQuery(function () {
	var austDay = new Date("October 25, 2015 00:00:00");
	$('#defaultCountdown').countdown({until: austDay, layout: '<div class="item"><p>{dn}</p> {dl}<div class="lines"></div></div> <div class="item"><p>{hn}</p> {hl}<div class="lines"></div></div> <div class="item"><p>{mn}</p> {ml}<div class="lines"></div></div> <div class="item"><p>{sn}</p> {sl}</div>'});
	$('#year').text(austDay.getFullYear());
});

//============================================================================== */
//* Control panel inital Script
//============================================================================== */
jQuery(document).ready(function(){
	$(".control_trigger").click(function(){
		$(".wplap_control_panel").toggle("fast");
		$(this).toggleClass("active");
		return false;
	});
});

//============================================================================== */
//* Main Tab init
//============================================================================== */
jQuery(document).ready(function() {
	$(".tab_content").hide();
	$(".tab_content:first").show(); 
	$("ul.tabs li").click(function() {
		$("ul.tabs li").removeClass("active");
		$(this).addClass("active");
		$(".tab_content").hide();
		var activeTab = $(this).attr("rel"); 
		$("#"+activeTab).fadeIn(); 
	});
});	


//============================================================================== */
//* Bacground slider init -- 
//* For more info go to www.buildinternet.com/project/supersized
//============================================================================== */
jQuery(function($){
	$.supersized({
		// Functionality
		slide_interval          :   5000,		// Length between transitions
		transition              :   1, 			// 0-None, 1-Fade, 2-Slide Top, 3-Slide Right, 4-Slide Bottom, 5-Slide Left, 6-Carousel Right, 7-Carousel Left
		transition_speed		:	700,		// Speed of transition
		// Components							
		slide_links				:	'blank',	// Individual links for each slide (Options: false, 'num', 'name', 'blank')
		slides 					:  	[			// Slideshow Images
								{image : 'img/hd/select/1.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/3.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/4.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/5.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/6.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/7.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/8.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/9.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/11.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/12.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/13.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''},
								{image : 'img/hd/select/14.jpg', thumb : 'img/gallery/thumb1.jpg', url : ''}
									]
	});
});
