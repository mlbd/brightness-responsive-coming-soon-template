//============================================================================== */
//* Subscripe form init
//============================================================================== */
jQuery(document).ready(function(){
    $('#subscribeform').submit(function(){
        var action = $(this).attr('action');
        $("#mesaj").slideUp(750,function() {
        $('#mesaj').hide();
        $('#newsletter_submit')
            .after('<img src="ajax-loader.gif" class="my_loader_gif" />')
            .attr('disabled','disabled');
        $.post(action, {
            email: $('#subcriber_email').val()
        },
            function(data){
                document.getElementById('mesaj').innerHTML = data;
                $('#mesaj').slideDown('slow');
                $('#subscribeform img.subscribe-loader').fadeOut('slow',function(){$(this).remove()});
                $('#newsletter_submit').removeAttr('disabled');
                if(data.match('success') != null) $('#subscribeform').slideUp('slow');
            }
        );
        });
        return false;
    });
});

//============================================================================== */
//* Contact Form init
//============================================================================== */
jQuery(document).ready(function(){
    $('#contact').submit(function(){
        var action = $(this).attr('action');
        $("#message").slideUp(750,function() {
        $('#message').hide();
        $('#submit')
            .after('<img src="ajax-loader.gif" class="contact-loader" />')
            .attr('disabled','disabled');
        $.post(action, {
            name: $('#name').val(),
            email: $('#email').val(),
            subject: $('#subject').val(),
            comments: $('#comments').val(),
        },
            function(data){
                document.getElementById('message').innerHTML = data;
                $('#message').slideDown('slow');
                $('#contact img.contact-loader').fadeOut('slow',function(){$(this).remove()});
                $('#submit').removeAttr('disabled');
                if(data.match('success') != null) $('#contact').slideUp('slow');
            }
        );
        });
        return false;
    });
});


//============================================================================== */
//* ToolTip init
//============================================================================== */
jQuery(document).ready(function() {
    $('.tooltip').tooltipster();
});

//============================================================================== */
//* Twitter feed setting init 
//* For more informaiton visit https://github.com/sonnyt/Tweetie 
//============================================================================== */
jQuery('.tweet').twittie(
    {dateFormat: '%b. %d, %Y',
    template: ' <div class="mythumbs">{{avatar}}</div> <div>{{tweet}}<div class="date">{{date}}</div></div>',
    count: 20 }
);

//============================================================================== */
//* Slider init
//============================================================================== */


//============================================================================== */
//* Sidebar Toggle init
//============================================================================== */
    jQuery('.bottom_arrow').click(function(){
        $('.side_con_sub').slideToggle('slow');
    });


//============================================================================== */
//* Tab toggle init
//============================================================================== */
jQuery('#google_map').click(function(){
    $( ".big_google_map" ).animate({height: "100%", opacity: "1"}, 300);
    $('.contact_us').animate({height: "0", opacity: "0",margin: "0"}, 300);
    $('.videos_area').animate({height: "0", opacity: "0"}, 300);
    $('#feed').animate({height: "0", opacity: "0"}, 300);
});
jQuery('#home').click(function(){
    $('.contact_us').animate({height: "100%", opacity: "1",'margin-bootom': "55px"}, 300);
    $( ".big_google_map" ).animate({height: "0", opacity: "0"}, 300);
    $('.videos_area').animate({height: "0", opacity: "0"}, 300);
    $('#feed').animate({height: "0", opacity: "0"}, 300);
});
jQuery('#videos').click(function(){
    $('.videos_area').animate({height: "100%", opacity: "1"}, 300);
    $('.contact_us').animate({height: "0", opacity: "0",margin: "0"}, 300);
    $( ".big_google_map" ).animate({height: "0", opacity: "0"}, 300);
    $('#feed').animate({height: "0", opacity: "0"}, 300);
});
jQuery('#tweet').click(function(){
    $('#feed').animate({height: "100%", opacity: "1"}, 300);
    $('.videos_area').animate({height: "0", opacity: "0"}, 300);
    $('.contact_us').animate({height: "0", opacity: "0",margin: "0"}, 300);
    $( ".big_google_map" ).animate({height: "0", opacity: "0"}, 300);
});

//============================================================================== */
//* Pattern toggle init
//============================================================================== */
jQuery('.myall_pattern .pattern').click(function(){
    pattern = jQuery(this).attr('rel');
    jQuery('body, .hole_container').css("background-image",pattern);
    return false;
});
