<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', '2RiirW9RQfRNavt649DCmQ');
    define('CONSUMER_SECRET', 'hInBC66iNRqZSFxWp3GHHkVJWkiV4CxZGCBO8chYc');

    // User Access Token
    define('ACCESS_TOKEN', '2150699568-D3ZGyFdpCLjBNtdI6jgh28wT0NhO6XHVTCVwGL1');
    define('ACCESS_SECRET', '0KmYiFUs5aiD6pO49cutvDPGSa0hpy5aqfBzxjTqYPnIb');